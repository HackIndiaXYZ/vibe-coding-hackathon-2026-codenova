import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import fetch from 'node-fetch'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3001

app.use(cors())
app.use(express.json())

const GOOGLE_KEY = process.env.GOOGLE_PLACES_API_KEY
const CLAUDE_KEY = process.env.CLAUDE_API_KEY
const GOOGLE_BASE = 'https://maps.googleapis.com/maps/api/place'

// ─── Search for a business by name + location ───────────────────────────────
app.post('/api/places/search', async (req, res) => {
  try {
    const { name, city, area } = req.body
    const query = `${name} ${area} ${city}`
    const url = `${GOOGLE_BASE}/textsearch/json?query=${encodeURIComponent(query)}&key=${GOOGLE_KEY}`
    const response = await fetch(url)
    const data = await response.json()

    if (!data.results || data.results.length === 0) {
      return res.status(404).json({ error: 'Business not found. Please check the name and location.' })
    }

    const place = data.results[0]
    res.json({
      placeId: place.place_id,
      name: place.name,
      lat: place.geometry.location.lat,
      lng: place.geometry.location.lng,
      address: place.formatted_address,
      rating: place.rating,
      totalReviews: place.user_ratings_total,
    })
  } catch (err) {
    console.error('Search error:', err)
    res.status(500).json({ error: 'Failed to search for business.' })
  }
})

// ─── Find nearby competitors ─────────────────────────────────────────────────
app.post('/api/places/nearby', async (req, res) => {
  try {
    const { lat, lng, type, userPlaceId } = req.body

    const typeMap = {
      restaurant: 'restaurant',
      cafe: 'cafe',
      salon: 'beauty_salon',
      clinic: 'doctor',
      coaching: 'school',
      gym: 'gym',
      hotel: 'lodging',
      shop: 'store',
    }

    const placeType = typeMap[type] || 'establishment'
    const url = `${GOOGLE_BASE}/nearbysearch/json?location=${lat},${lng}&radius=2000&type=${placeType}&key=${GOOGLE_KEY}`
    const response = await fetch(url)
    const data = await response.json()

    const competitors = data.results
      .filter(p => p.place_id !== userPlaceId)
      .slice(0, 5)
      .map(p => ({
        placeId: p.place_id,
        name: p.name,
        rating: p.rating || 0,
        totalReviews: p.user_ratings_total || 0,
        priceLevel: p.price_level || 1,
        address: p.vicinity,
        lat: p.geometry.location.lat,
        lng: p.geometry.location.lng,
        distance: calculateDistance(lat, lng, p.geometry.location.lat, p.geometry.location.lng),
      }))
      .sort((a, b) => a.distance - b.distance)

    res.json(competitors)
  } catch (err) {
    console.error('Nearby error:', err)
    res.status(500).json({ error: 'Failed to find competitors.' })
  }
})

// ─── Get place details + reviews ─────────────────────────────────────────────
app.get('/api/places/details/:placeId', async (req, res) => {
  try {
    const { placeId } = req.params
    const fields = 'name,rating,reviews,user_ratings_total,price_level,opening_hours'
    const url = `${GOOGLE_BASE}/details/json?place_id=${placeId}&fields=${fields}&key=${GOOGLE_KEY}`
    const response = await fetch(url)
    const data = await response.json()

    if (data.status !== 'OK') {
      return res.status(404).json({ error: 'Place details not found.' })
    }

    res.json({
      name: data.result.name,
      rating: data.result.rating,
      totalReviews: data.result.user_ratings_total,
      priceLevel: data.result.price_level,
      reviews: (data.result.reviews || []).slice(0, 5).map(r => ({
        rating: r.rating,
        text: r.text,
        time: r.relative_time_description,
      })),
    })
  } catch (err) {
    console.error('Details error:', err)
    res.status(500).json({ error: 'Failed to get place details.' })
  }
})

// ─── Claude AI analysis ───────────────────────────────────────────────────────
app.post('/api/analyze', async (req, res) => {
  try {
    const { businessName, category, competitors } = req.body

    const prompt = `You are a business intelligence analyst helping a small Indian business owner understand their competition.

Business: "${businessName}" (${category})

Here are their 5 nearest competitors with real Google review data:
${competitors.map((c, i) => `
${i + 1}. ${c.name}
   Rating: ${c.rating}/5 (${c.totalReviews} reviews)
   Price Level: ${'₹'.repeat(c.priceLevel || 1)}
   Recent reviews: ${(c.reviews || []).map(r => `"${r.text?.substring(0, 100)}" (${r.rating}★)`).join(' | ')}
`).join('\n')}

Analyze this data and return ONLY a valid JSON object (no markdown, no explanation, just JSON):
{
  "weeklyAction": "One specific actionable sentence the business owner should do THIS WEEK based on competitor weaknesses. Max 20 words. Plain English.",
  "actionReason": "One sentence explaining why this action will work, citing specific competitor data. Max 25 words.",
  "threatLevel": "high or medium or low",
  "topThreats": ["competitor name and why they are dangerous", "competitor name and why", "competitor name and why"],
  "topOpportunities": ["specific gap in the market no competitor fills", "another gap", "another gap"],
  "marketGap": "The single biggest thing customers want that NONE of the competitors offer. One sentence.",
  "competitorSummaries": [
    {
      "name": "competitor name",
      "rating": 4.2,
      "trend": "improving or declining or stable",
      "strengthTags": ["what they do well", "another strength"],
      "weaknessTags": ["main complaint from reviews", "another weakness"],
      "threatLevel": "high or medium or low",
      "oneLineSummary": "10 word plain English summary of this competitor"
    }
  ],
  "overallInsight": "One bold insight about the competitive landscape. Max 20 words. Something surprising or actionable."
}`

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CLAUDE_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }],
      }),
    })

    const data = await response.json()
    const text = data.content[0].text
    const clean = text.replace(/```json|```/g, '').trim()
    const analysis = JSON.parse(clean)
    res.json(analysis)
  } catch (err) {
    console.error('Analyze error:', err)
    res.status(500).json({ error: 'AI analysis failed. Please try again.' })
  }
})

// ─── Helper: calculate distance in meters ────────────────────────────────────
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371000
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2)
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))
}

app.listen(PORT, () => {
  console.log(`✅ Scout server running at http://localhost:${PORT}`)
})
