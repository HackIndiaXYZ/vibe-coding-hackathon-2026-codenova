import axios from 'axios'

const api = axios.create({ baseURL: '/api' })

export const searchBusiness = (name, city, area) =>
  api.post('/places/search', { name, city, area }).then(r => r.data)

export const findCompetitors = (lat, lng, type, userPlaceId) =>
  api.post('/places/nearby', { lat, lng, type, userPlaceId }).then(r => r.data)

export const getPlaceDetails = (placeId) =>
  api.get(`/places/details/${placeId}`).then(r => r.data)

export const analyzeCompetitors = (businessName, category, competitors) =>
  api.post('/analyze', { businessName, category, competitors }).then(r => r.data)

export default api
