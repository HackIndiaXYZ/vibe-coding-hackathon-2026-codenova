import React from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'

export default function NotFound() {
  const navigate = useNavigate()
  return (
    <div className="min-h-screen bg-[#0F1729] flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        <div className="text-7xl mb-6">🔍</div>
        <h1 className="text-4xl font-bold text-white mb-3">Page not found</h1>
        <p className="text-white/60 text-lg mb-8">
          Oops! Looks like this page went scouting and got lost.
        </p>
        <button
          onClick={() => navigate('/')}
          className="bg-amber-400 hover:bg-amber-500 text-[#0F1729] font-bold px-8 py-4 rounded-xl
                     transition-all duration-200 flex items-center gap-2 mx-auto active:scale-95"
        >
          <ArrowLeft size={18} /> Back to Home
        </button>
      </div>
    </div>
  )
}
