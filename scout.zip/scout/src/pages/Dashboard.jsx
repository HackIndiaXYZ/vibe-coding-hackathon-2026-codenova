import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Star, TrendingUp, TrendingDown, Minus, ChevronDown, ChevronUp, MapPin, AlertTriangle, Lightbulb, BarChart2, RefreshCw } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'

function StarRating({ rating, size = 14 }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star key={i} size={size}
          className={i <= Math.round(rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-200 fill-slate-200'}
        />
      ))}
    </div>
  )
}

function ThreatBadge({ level }) {
  const map = {
    high: 'bg-red-50 text-red-700 border-red-200',
    medium: 'bg-amber-50 text-amber-700 border-amber-200',
    low: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  }
  const labels = { high: '🔴 High threat', medium: '🟡 Watch them', low: '🟢 You\'re winning' }
  return (
    <span className={`text-xs font-semibold px-3 py-1 rounded-full border ${map[level] || map.medium}`}>
      {labels[level] || labels.medium}
    </span>
  )
}

function TrendIcon({ trend }) {
  if (trend === 'improving') return <TrendingUp size={16} className="text-red-500" />
  if (trend === 'declining') return <TrendingDown size={16} className="text-emerald-500" />
  return <Minus size={16} className="text-slate-400" />
}

function CompetitorCard({ competitor, summary, index }) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className={`bg-white rounded-2xl shadow-card overflow-hidden fade-slide-up stagger-${index + 1}`}>
      <div className="p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-bold text-[#0F1729] text-base truncate">{competitor.name}</span>
              <TrendIcon trend={summary?.trend} />
            </div>
            <div className="flex items-center gap-1 text-slate-400 text-sm">
              <MapPin size={12} />
              <span className="truncate">{competitor.address}</span>
            </div>
          </div>
          <ThreatBadge level={summary?.threatLevel || 'medium'} />
        </div>

        {/* Rating row */}
        <div className="flex items-center gap-3 mb-3">
          <StarRating rating={competitor.rating} />
          <span className="font-bold text-[#0F1729] text-lg">{competitor.rating?.toFixed(1)}</span>
          <span className="text-slate-400 text-sm">({competitor.totalReviews?.toLocaleString()} reviews)</span>
        </div>

        {/* Summary */}
        {summary?.oneLineSummary && (
          <p className="text-slate-500 text-sm mb-3 italic">"{summary.oneLineSummary}"</p>
        )}

        {/* Tags preview */}
        <div className="flex flex-wrap gap-2">
          {(summary?.weaknessTags || []).slice(0, 2).map((tag, i) => (
            <span key={i} className="tag-red text-xs">❌ {tag}</span>
          ))}
          {(summary?.strengthTags || []).slice(0, 1).map((tag, i) => (
            <span key={i} className="tag-green text-xs">✅ {tag}</span>
          ))}
        </div>

        <button
          onClick={() => setExpanded(!expanded)}
          className="flex items-center gap-1 text-amber-500 text-sm font-medium mt-3 hover:text-amber-600 transition-colors"
        >
          {expanded ? 'Hide details' : 'See full details'}
          {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
      </div>

      {/* Expanded details */}
      {expanded && (
        <div className="border-t border-slate-100 p-5 bg-slate-50">
          <div className="grid sm:grid-cols-2 gap-4 mb-4">
            <div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Their Weaknesses</div>
              <div className="space-y-1">
                {(summary?.weaknessTags || []).map((tag, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-red-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400 flex-shrink-0" />
                    {tag}
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Their Strengths</div>
              <div className="space-y-1">
                {(summary?.strengthTags || []).map((tag, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-emerald-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 flex-shrink-0" />
                    {tag}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent reviews */}
          {competitor.reviews && competitor.reviews.length > 0 && (
            <div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Recent Customer Reviews</div>
              <div className="space-y-2">
                {competitor.reviews.slice(0, 3).map((r, i) => (
                  <div key={i} className="bg-white rounded-xl p-3 border border-slate-200">
                    <div className="flex items-center gap-2 mb-1">
                      <StarRating rating={r.rating} size={12} />
                      <span className="text-xs text-slate-400">{r.time}</span>
                    </div>
                    <p className="text-slate-600 text-sm leading-relaxed line-clamp-3">{r.text}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default function Dashboard({ businessInfo, competitors, analysis }) {
  const navigate = useNavigate()
  const [showDetailedAnalytics, setShowDetailedAnalytics] = useState(false)

  const chartData = competitors.map(c => ({
    name: c.name.split(' ').slice(0, 2).join(' '),
    rating: c.rating || 0,
  }))

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navbar */}
      <nav className="bg-[#0F1729] sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2">
            <span className="text-xl">🔍</span>
            <span className="text-white font-bold text-lg">Scout</span>
          </a>
          <button
            onClick={() => navigate('/start')}
            className="flex items-center gap-2 text-white/70 hover:text-white text-sm transition-colors"
          >
            <RefreshCw size={14} /> New Report
          </button>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 py-8">

        {/* Business header */}
        <div className="mb-6">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Competitive Report for</div>
          <h1 className="text-2xl font-bold text-[#0F1729]">{businessInfo.name}</h1>
          <div className="flex items-center gap-1 text-slate-500 text-sm mt-1">
            <MapPin size={14} />
            {businessInfo.area}, {businessInfo.city}
          </div>
        </div>

        {/* ── WEEKLY ACTION CARD ── */}
        <div className="bg-white rounded-2xl shadow-card border-l-4 border-amber-400 p-6 mb-6 fade-slide-up">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-amber-500 text-xs font-bold tracking-widest uppercase">🎯 This Week's Action</span>
          </div>
          <p className="text-[#0F1729] font-bold text-xl sm:text-2xl leading-snug mb-3">
            {analysis.weeklyAction}
          </p>
          <div className="flex items-start gap-2 bg-amber-50 rounded-xl p-3">
            <Lightbulb size={16} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-amber-700 text-sm">{analysis.actionReason}</p>
          </div>
          {analysis.overallInsight && (
            <p className="text-slate-400 text-sm mt-3 pt-3 border-t border-slate-100 italic">
              💡 {analysis.overallInsight}
            </p>
          )}
        </div>

        {/* ── SIMPLE VIEW ── */}
        <div className="grid sm:grid-cols-3 gap-4 mb-6">
          {/* Threat level */}
          <div className="bg-white rounded-2xl shadow-card p-5 fade-slide-up stagger-1">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Threat Level</div>
            <div className={`text-2xl font-bold capitalize mb-1 ${
              analysis.threatLevel === 'high' ? 'text-red-500' :
              analysis.threatLevel === 'medium' ? 'text-amber-500' : 'text-emerald-500'
            }`}>
              {analysis.threatLevel === 'high' ? '🔴' : analysis.threatLevel === 'medium' ? '🟡' : '🟢'} {analysis.threatLevel}
            </div>
            <p className="text-slate-400 text-xs">Competition in your area</p>
          </div>

          {/* Competitors count */}
          <div className="bg-white rounded-2xl shadow-card p-5 fade-slide-up stagger-2">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Competitors Found</div>
            <div className="text-2xl font-bold text-[#0F1729] mb-1">{competitors.length} nearby</div>
            <p className="text-slate-400 text-xs">Within 2km of your location</p>
          </div>

          {/* Top opportunity */}
          <div className="bg-emerald-50 rounded-2xl shadow-card p-5 border border-emerald-100 fade-slide-up stagger-3">
            <div className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-2">Your #1 Opportunity</div>
            <p className="text-emerald-800 text-sm font-semibold leading-snug">
              {analysis.topOpportunities?.[0] || 'Check detailed analytics'}
            </p>
          </div>
        </div>

        {/* ── Threats & Opportunities ── */}
        <div className="grid md:grid-cols-2 gap-5 mb-6">
          <div className="bg-white rounded-2xl shadow-card p-5 fade-slide-up">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle size={18} className="text-red-500" />
              <h3 className="font-bold text-[#0F1729]">Watch Out For</h3>
            </div>
            <div className="space-y-2">
              {(analysis.topThreats || []).map((threat, i) => (
                <div key={i} className="flex items-start gap-2 p-3 bg-red-50 rounded-xl border border-red-100">
                  <span className="text-red-500 text-sm flex-shrink-0">⚠️</span>
                  <p className="text-red-700 text-sm">{threat}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-card p-5 fade-slide-up">
            <div className="flex items-center gap-2 mb-4">
              <Lightbulb size={18} className="text-emerald-500" />
              <h3 className="font-bold text-[#0F1729]">Your Opportunities</h3>
            </div>
            <div className="space-y-2">
              {(analysis.topOpportunities || []).map((opp, i) => (
                <div key={i} className="flex items-start gap-2 p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                  <span className="text-emerald-500 text-sm flex-shrink-0">💡</span>
                  <p className="text-emerald-700 text-sm">{opp}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── Market Gap ── */}
        {analysis.marketGap && (
          <div className="bg-[#0F1729] rounded-2xl p-6 mb-6 fade-slide-up">
            <div className="section-label mb-2">Market Gap You Can Fill</div>
            <p className="text-white font-bold text-lg">{analysis.marketGap}</p>
          </div>
        )}

        {/* ── Competitor Overview ── */}
        <div className="mb-6">
          <h2 className="text-lg font-bold text-[#0F1729] mb-4">Your 5 Competitors</h2>
          <div className="space-y-4">
            {competitors.map((c, i) => {
              const summary = analysis.competitorSummaries?.find(s =>
                s.name?.toLowerCase().includes(c.name?.toLowerCase().split(' ')[0]?.toLowerCase())
              ) || analysis.competitorSummaries?.[i]
              return (
                <CompetitorCard key={c.placeId} competitor={c} summary={summary} index={i} />
              )
            })}
          </div>
        </div>

        {/* ── Detailed Analytics Toggle ── */}
        <button
          onClick={() => setShowDetailedAnalytics(!showDetailedAnalytics)}
          className="w-full flex items-center justify-center gap-2 bg-white rounded-2xl shadow-card p-4 text-slate-500 hover:text-slate-700 font-medium transition-colors mb-4 border border-slate-200"
        >
          <BarChart2 size={18} />
          {showDetailedAnalytics ? 'Hide Detailed Analytics' : 'See Detailed Analytics'}
          {showDetailedAnalytics ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </button>

        {/* ── Detailed Analytics ── */}
        {showDetailedAnalytics && (
          <div className="space-y-6 fade-slide-up">
            {/* Rating comparison chart */}
            <div className="bg-white rounded-2xl shadow-card p-6">
              <h3 className="font-bold text-[#0F1729] mb-1">Rating Comparison</h3>
              <p className="text-slate-400 text-sm mb-6">How your competitors' ratings compare to each other</p>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <YAxis domain={[0, 5]} tick={{ fontSize: 11, fill: '#94a3b8' }} />
                  <Tooltip
                    formatter={(val) => [`${val}/5`, 'Rating']}
                    contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '13px' }}
                  />
                  <Bar dataKey="rating" radius={[8, 8, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell
                        key={index}
                        fill={entry.rating >= 4.0 ? '#EF4444' : entry.rating >= 3.5 ? '#F59E0B' : '#10B981'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <div className="flex gap-4 mt-3 text-xs text-slate-400 justify-center">
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-red-400 inline-block" /> 4.0+ (High threat)</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-amber-400 inline-block" /> 3.5–4.0 (Watch)</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-emerald-400 inline-block" /> Below 3.5 (Your opportunity)</span>
              </div>
            </div>

            {/* Full weakness breakdown */}
            <div className="bg-white rounded-2xl shadow-card p-6">
              <h3 className="font-bold text-[#0F1729] mb-1">Common Weaknesses Across All Competitors</h3>
              <p className="text-slate-400 text-sm mb-4">These are the areas where customers are most unhappy — your chance to stand out</p>
              <div className="grid sm:grid-cols-2 gap-3">
                {analysis.competitorSummaries
                  ?.flatMap(s => s.weaknessTags || [])
                  .filter((v, i, a) => a.indexOf(v) === i)
                  .slice(0, 8)
                  .map((tag, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 bg-red-50 rounded-xl border border-red-100">
                      <span className="text-red-500">❌</span>
                      <span className="text-red-700 text-sm font-medium">{tag}</span>
                    </div>
                  ))
                }
              </div>
            </div>

            {/* Review count comparison */}
            <div className="bg-white rounded-2xl shadow-card p-6">
              <h3 className="font-bold text-[#0F1729] mb-4">Review Count Comparison</h3>
              <div className="space-y-3">
                {[...competitors].sort((a, b) => b.totalReviews - a.totalReviews).map((c, i) => {
                  const max = Math.max(...competitors.map(x => x.totalReviews || 0))
                  const pct = max > 0 ? ((c.totalReviews || 0) / max) * 100 : 0
                  return (
                    <div key={i}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-700 font-medium truncate max-w-[70%]">{c.name}</span>
                        <span className="text-slate-500">{c.totalReviews?.toLocaleString()} reviews</span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#0F1729] rounded-full transition-all duration-700"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="text-center py-8 text-slate-400 text-sm">
          <p>Scout • Competitive intelligence for Indian small businesses</p>
          <button onClick={() => navigate('/start')} className="text-amber-500 hover:text-amber-600 font-medium mt-1 inline-block">
            Run a new report →
          </button>
        </div>
      </div>
    </div>
  )
}
