import React, { useEffect, useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { Star, MapPin, ArrowRight, AlertCircle } from 'lucide-react'

const LOADING_MESSAGES = [
  'Finding your business on Google...',
  'Locating competitors near you...',
  'Reading their reviews...',
  'Spotting their weaknesses...',
  'Analysing the data with AI...',
  'Building your action plan...',
]

function StarRating({ rating }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map(i => (
        <Star
          key={i}
          size={14}
          className={i <= Math.round(rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-200 fill-slate-200'}
        />
      ))}
    </div>
  )
}

function PriceLevel({ level = 1 }) {
  const symbols = ['₹', '₹₹', '₹₹₹', '₹₹₹₹']
  return <span className="text-slate-400 text-sm">{symbols[Math.min(level - 1, 3)]}</span>
}

export default function Discovery({ businessInfo, placeData, setCompetitors, setAnalysis }) {
  const navigate = useNavigate()
  const [phase, setPhase] = useState('loading') // loading | results | error
  const [msgIndex, setMsgIndex] = useState(0)
  const [progress, setProgress] = useState(0)
  const [competitors, setLocalCompetitors] = useState([])
  const [errorMsg, setErrorMsg] = useState('')
  const [visibleCards, setVisibleCards] = useState(0)
  const didRun = useRef(false)

  useEffect(() => {
    if (didRun.current) return
    didRun.current = true
    runPipeline()
  }, [])

  // Cycle loading messages
  useEffect(() => {
    if (phase !== 'loading') return
    const interval = setInterval(() => {
      setMsgIndex(i => (i + 1) % LOADING_MESSAGES.length)
      setProgress(p => Math.min(p + 15, 90))
    }, 2000)
    return () => clearInterval(interval)
  }, [phase])

  async function runPipeline() {
    try {
      // Step 1: Find business
      setMsgIndex(0)
      const searchRes = await axios.post('/api/places/search', {
        name: businessInfo.name,
        city: businessInfo.city,
        area: businessInfo.area,
      })
      const place = searchRes.data
      setProgress(20)

      // Step 2: Find competitors
      setMsgIndex(1)
      const nearbyRes = await axios.post('/api/places/nearby', {
        lat: place.lat,
        lng: place.lng,
        type: businessInfo.category,
        userPlaceId: place.placeId,
      })
      const foundCompetitors = nearbyRes.data
      setProgress(45)

      // Step 3: Get reviews for each competitor
      setMsgIndex(2)
      const competitorsWithReviews = await Promise.all(
        foundCompetitors.map(async c => {
          try {
            const detailsRes = await axios.get(`/api/places/details/${c.placeId}`)
            return { ...c, reviews: detailsRes.data.reviews || [] }
          } catch {
            return { ...c, reviews: [] }
          }
        })
      )
      setProgress(65)

      // Step 4: Claude analysis
      setMsgIndex(4)
      const analysisRes = await axios.post('/api/analyze', {
        businessName: businessInfo.name,
        category: businessInfo.category,
        competitors: competitorsWithReviews,
      })
      setProgress(90)

      // Done
      setLocalCompetitors(competitorsWithReviews)
      setCompetitors(competitorsWithReviews)
      setAnalysis(analysisRes.data)
      setProgress(100)

      setTimeout(() => {
        setPhase('results')
        // Animate cards in
        competitorsWithReviews.forEach((_, i) => {
          setTimeout(() => setVisibleCards(v => v + 1), i * 150)
        })
      }, 500)
    } catch (err) {
      console.error(err)
      setErrorMsg(err.response?.data?.error || 'Something went wrong. Please check your API keys and try again.')
      setPhase('error')
    }
  }

  const handleViewReport = () => navigate('/dashboard')

  // ── Loading state ──
  if (phase === 'loading') {
    return (
      <div className="min-h-screen bg-[#0F1729] flex flex-col items-center justify-center px-4">
        <div className="text-center max-w-sm">
          {/* Animated rings */}
          <div className="relative w-24 h-24 mx-auto mb-8">
            <div className="absolute inset-0 rounded-full border-4 border-amber-400/20 animate-ping" />
            <div className="absolute inset-2 rounded-full border-4 border-amber-400/40 animate-ping" style={{ animationDelay: '0.3s' }} />
            <div className="absolute inset-4 rounded-full bg-amber-400 flex items-center justify-center">
              <span className="text-2xl">🔍</span>
            </div>
          </div>

          <h2 className="text-white font-bold text-xl mb-3">{LOADING_MESSAGES[msgIndex]}</h2>
          <p className="text-white/40 text-sm mb-8">Scanning Google for real data near {businessInfo.area}, {businessInfo.city}</p>

          {/* Progress bar */}
          <div className="h-2 bg-white/10 rounded-full overflow-hidden max-w-xs mx-auto mb-3">
            <div
              className="h-full bg-amber-400 rounded-full transition-all duration-1000"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-white/40 text-xs">This takes about 15–20 seconds</p>
        </div>
      </div>
    )
  }

  // ── Error state ──
  if (phase === 'error') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-card p-8 max-w-md text-center">
          <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle size={28} className="text-red-500" />
          </div>
          <h2 className="text-xl font-bold text-[#0F1729] mb-2">Something went wrong</h2>
          <p className="text-slate-500 mb-6">{errorMsg}</p>
          <button onClick={() => navigate('/start')} className="btn-navy w-full">
            Try Again
          </button>
        </div>
      </div>
    )
  }

  // ── Results state ──
  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-[#0F1729] h-16 flex items-center px-6">
        <a href="/" className="flex items-center gap-2">
          <span className="text-xl">🔍</span>
          <span className="text-white font-bold text-lg">Scout</span>
        </a>
      </nav>

      <div className="max-w-2xl mx-auto px-4 py-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-50 rounded-full mb-4">
            <span className="text-3xl">👀</span>
          </div>
          <h1 className="text-2xl font-bold text-[#0F1729] mb-2">We found your competitors!</h1>
          <p className="text-slate-500">
            Here's who you're up against in <strong>{businessInfo.area}, {businessInfo.city}</strong>
          </p>
        </div>

        <div className="space-y-4 mb-8">
          {competitors.map((c, i) => (
            <div
              key={c.placeId}
              className={`bg-white rounded-2xl shadow-card p-5 transition-all duration-500 ${i < visibleCards ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-[#0F1729] text-base truncate mb-1">{c.name}</div>
                  <div className="flex items-center gap-1 text-slate-400 text-sm mb-2">
                    <MapPin size={12} />
                    <span className="truncate">{c.address}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <StarRating rating={c.rating} />
                    <span className="font-bold text-[#0F1729]">{c.rating?.toFixed(1)}</span>
                    <span className="text-slate-400 text-sm">({c.totalReviews?.toLocaleString()} reviews)</span>
                  </div>
                </div>

                <div className="text-right flex-shrink-0">
                  <div className="bg-slate-100 text-slate-600 text-xs font-semibold px-2 py-1 rounded-full mb-2">
                    {c.distance < 1000 ? `${c.distance}m away` : `${(c.distance / 1000).toFixed(1)}km away`}
                  </div>
                  <PriceLevel level={c.priceLevel} />
                </div>
              </div>
            </div>
          ))}
        </div>

        <button onClick={handleViewReport} className="btn-primary w-full text-base">
          See My Intelligence Report <ArrowRight size={20} />
        </button>

        <p className="text-center text-slate-400 text-sm mt-4">
          Our AI has already analysed all {competitors.length} competitors for you
        </p>
      </div>
    </div>
  )
}
