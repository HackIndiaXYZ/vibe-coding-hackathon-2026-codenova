import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, ArrowRight, ChevronRight } from 'lucide-react'

const CATEGORIES = [
  { id: 'restaurant', label: 'Restaurant', emoji: '🍽️' },
  { id: 'cafe', label: 'Café', emoji: '☕' },
  { id: 'salon', label: 'Salon & Spa', emoji: '💇' },
  { id: 'clinic', label: 'Clinic', emoji: '🏥' },
  { id: 'coaching', label: 'Coaching Centre', emoji: '📚' },
  { id: 'gym', label: 'Gym', emoji: '💪' },
  { id: 'shop', label: 'Retail Shop', emoji: '🛒' },
  { id: 'hotel', label: 'Hotel', emoji: '🏨' },
]

export default function Onboarding({ setBusinessInfo, setPlaceData }) {
  const navigate = useNavigate()
  const [step, setStep] = useState(1)
  const [name, setName] = useState('')
  const [category, setCategory] = useState('')
  const [city, setCity] = useState('')
  const [area, setArea] = useState('')
  const [error, setError] = useState('')

  const goNext = () => {
    setError('')
    if (step === 1) {
      if (!name.trim()) { setError('Please enter your business name.'); return }
      setStep(2)
    } else if (step === 2) {
      if (!category) { setError('Please select your business type.'); return }
      setStep(3)
    }
  }

  const goBack = () => {
    setError('')
    setStep(s => s - 1)
  }

  const handleSubmit = () => {
    setError('')
    if (!city.trim()) { setError('Please enter your city.'); return }
    if (!area.trim()) { setError('Please enter your area or neighbourhood.'); return }

    setBusinessInfo({ name: name.trim(), category, city: city.trim(), area: area.trim() })
    setPlaceData(null)
    navigate('/discovery')
  }

  const progress = (step / 3) * 100

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Navbar */}
      <nav className="bg-[#0F1729] h-16 flex items-center px-6">
        <a href="/" className="flex items-center gap-2">
          <span className="text-xl">🔍</span>
          <span className="text-white font-bold text-lg">Scout</span>
        </a>
      </nav>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center p-4 py-10">
        <div className="bg-white rounded-2xl shadow-card w-full max-w-lg p-8">

          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between mb-2">
              {['Your Business', 'Category', 'Location'].map((label, i) => (
                <span
                  key={i}
                  className={`text-xs font-semibold ${i + 1 <= step ? 'text-amber-500' : 'text-slate-400'}`}
                >
                  {label}
                </span>
              ))}
            </div>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-400 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Step 1 */}
          {step === 1 && (
            <div className="fade-slide-up" style={{ animationDelay: '0s' }}>
              <h2 className="text-2xl font-bold text-[#0F1729] mb-2">What is your business called?</h2>
              <p className="text-slate-500 mb-6">Enter the name exactly as it appears on Google Maps.</p>
              <input
                type="text"
                className="input-field mb-2"
                placeholder="e.g. Sharma Biryani House"
                value={name}
                onChange={e => setName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && goNext()}
                autoFocus
              />
              {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
              <button onClick={goNext} className="btn-primary w-full mt-4">
                Continue <ArrowRight size={18} />
              </button>
            </div>
          )}

          {/* Step 2 */}
          {step === 2 && (
            <div className="fade-slide-up" style={{ animationDelay: '0s' }}>
              <button onClick={goBack} className="flex items-center gap-1 text-slate-400 hover:text-slate-600 text-sm mb-6 transition-colors">
                <ArrowLeft size={16} /> Back
              </button>
              <h2 className="text-2xl font-bold text-[#0F1729] mb-2">What kind of business is it?</h2>
              <p className="text-slate-500 mb-6">Choose the one that fits best.</p>
              <div className="grid grid-cols-2 gap-3 mb-4">
                {CATEGORIES.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setCategory(cat.id)}
                    className={`flex items-center gap-3 p-4 rounded-xl border-2 transition-all duration-200 text-left
                      ${category === cat.id
                        ? 'border-amber-400 bg-amber-50 text-[#0F1729]'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                  >
                    <span className="text-2xl">{cat.emoji}</span>
                    <span className="font-medium text-sm">{cat.label}</span>
                  </button>
                ))}
              </div>
              {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
              <button onClick={goNext} className="btn-primary w-full mt-2">
                Continue <ArrowRight size={18} />
              </button>
            </div>
          )}

          {/* Step 3 */}
          {step === 3 && (
            <div className="fade-slide-up" style={{ animationDelay: '0s' }}>
              <button onClick={goBack} className="flex items-center gap-1 text-slate-400 hover:text-slate-600 text-sm mb-6 transition-colors">
                <ArrowLeft size={16} /> Back
              </button>
              <h2 className="text-2xl font-bold text-[#0F1729] mb-2">Where is your business located?</h2>
              <p className="text-slate-500 mb-6">We use this to find competitors near you.</p>
              <div className="space-y-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">City</label>
                  <input
                    type="text"
                    className="input-field"
                    placeholder="e.g. Pune"
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    autoFocus
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Area / Neighbourhood</label>
                  <input
                    type="text"
                    className="input-field"
                    placeholder="e.g. Koregaon Park"
                    value={area}
                    onChange={e => setArea(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleSubmit()}
                  />
                </div>
              </div>
              {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
              <button onClick={handleSubmit} className="btn-primary w-full mt-2">
                Find My Competitors <ChevronRight size={18} />
              </button>
            </div>
          )}

          {/* Step indicator */}
          <p className="text-center text-slate-400 text-sm mt-6">Step {step} of 3</p>
        </div>
      </div>
    </div>
  )
}
