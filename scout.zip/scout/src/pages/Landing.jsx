import React from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, Star, TrendingUp, Bell, Lightbulb, BarChart2, Smartphone, Check, Zap } from 'lucide-react'

export default function Landing() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen font-sans">
      {/* ── Navbar ── */}
      <nav className="bg-[#0F1729] sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🔍</span>
            <span className="text-white font-bold text-xl tracking-tight">Scout</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#how" className="text-white/70 hover:text-white text-sm transition-colors">How it works</a>
            <a href="#features" className="text-white/70 hover:text-white text-sm transition-colors">Features</a>
            <a href="#pricing" className="text-white/70 hover:text-white text-sm transition-colors">Pricing</a>
          </div>
          <button
            onClick={() => navigate('/start')}
            className="bg-amber-400 hover:bg-amber-500 text-[#0F1729] font-semibold px-5 py-2 rounded-xl text-sm transition-all duration-200 active:scale-95"
          >
            Start Free
          </button>
        </div>
      </nav>

      {/* ── Hero ── */}
      <section className="bg-[#0F1729] pt-16 pb-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-amber-400/10 border border-amber-400/30 rounded-full px-4 py-2 mb-6">
              <span className="text-amber-400 text-sm font-semibold">🏆 Built for Indian Small Businesses</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Know exactly what your
              <span className="text-amber-400"> competitors </span>
              are doing — every week
            </h1>

            <p className="text-white/70 text-lg mb-8 leading-relaxed">
              Scout monitors your competitors on Google and tells you exactly one thing to do to stay ahead.
              Simple. Automatic. Powerful.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 mb-8">
              <button
                onClick={() => navigate('/start')}
                className="bg-amber-400 hover:bg-amber-500 text-[#0F1729] font-bold px-8 py-4 rounded-xl text-base transition-all duration-200 flex items-center justify-center gap-2 active:scale-95 shadow-lg"
              >
                Start Free — It's Quick <ArrowRight size={18} />
              </button>
              <a
                href="#how"
                className="border-2 border-white/20 text-white hover:bg-white/10 font-semibold px-8 py-4 rounded-xl text-base transition-all duration-200 flex items-center justify-center gap-2"
              >
                See How It Works
              </a>
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-white/50">
              <span className="flex items-center gap-1"><Zap size={14} className="text-amber-400" /> Takes 2 minutes</span>
              <span className="flex items-center gap-1"><Check size={14} className="text-amber-400" /> No credit card needed</span>
              <span className="flex items-center gap-1"><Check size={14} className="text-amber-400" /> Real data, not guesses</span>
            </div>
          </div>

          {/* Hero action card mockup */}
          <div className="mt-12 lg:mt-0 lg:absolute lg:right-8 lg:top-32 max-w-sm">
            <div className="bg-white rounded-2xl shadow-2xl p-5 border-l-4 border-amber-400">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-amber-400 font-bold text-xs tracking-widest uppercase">🎯 This Week's Action</span>
              </div>
              <p className="text-[#0F1729] font-bold text-lg leading-snug mb-3">
                Your top competitor has 40+ complaints about slow service. Promote your fast delivery now.
              </p>
              <p className="text-slate-500 text-sm">
                Based on: 43 recent reviews mentioning slow service at <strong>Paradise Biryani</strong>
              </p>
              <div className="mt-3 flex gap-2">
                <span className="bg-red-50 text-red-600 text-xs px-2 py-1 rounded-full border border-red-200">🐌 Slow service</span>
                <span className="bg-emerald-50 text-emerald-600 text-xs px-2 py-1 rounded-full border border-emerald-200">💡 Your opportunity</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Stats bar ── */}
      <section className="bg-[#1a2a45] py-8 px-4">
        <div className="max-w-4xl mx-auto grid grid-cols-3 gap-4">
          {[
            { val: '63M+', label: 'Small businesses in India' },
            { val: '5 min', label: 'To get your first report' },
            { val: '₹499/mo', label: 'Less than a daily chai' },
          ].map((s, i) => (
            <div key={i} className="text-center border-r border-white/10 last:border-0">
              <div className="text-amber-400 font-bold text-2xl sm:text-3xl">{s.val}</div>
              <div className="text-white/60 text-xs sm:text-sm mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── How it works ── */}
      <section id="how" className="bg-white py-20 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <div className="section-label">How It Works</div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0F1729] mb-4">
            Three steps to outsmart your competition
          </h2>
          <p className="text-slate-500 text-lg mb-12 max-w-xl mx-auto">
            No technical knowledge needed. If you can use WhatsApp, you can use Scout.
          </p>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: '🏪',
                bg: 'bg-purple-50',
                step: '01',
                title: 'Tell us about your business',
                desc: 'Enter your business name and location. Takes less than 2 minutes.',
              },
              {
                icon: '🔍',
                bg: 'bg-blue-50',
                step: '02',
                title: 'We find your competitors',
                desc: 'Scout automatically finds the 5 nearest businesses competing with you — using real Google data.',
              },
              {
                icon: '🎯',
                bg: 'bg-emerald-50',
                step: '03',
                title: 'Get your weekly action',
                desc: 'One clear instruction telling you exactly what to do to stay ahead. No guessing.',
              },
            ].map((item, i) => (
              <div key={i} className="relative">
                {i < 2 && (
                  <div className="hidden md:block absolute top-12 left-full w-full h-0.5 bg-slate-100 z-0" style={{ width: '20%', left: '90%' }}>
                    <ArrowRight size={16} className="absolute right-0 -top-2 text-slate-300" />
                  </div>
                )}
                <div className="bg-slate-50 rounded-2xl p-6 text-left relative z-10 h-full">
                  <div className={`${item.bg} w-14 h-14 rounded-xl flex items-center justify-center text-2xl mb-4`}>
                    {item.icon}
                  </div>
                  <div className="text-xs font-bold text-slate-400 tracking-wider mb-2">STEP {item.step}</div>
                  <h3 className="font-bold text-[#0F1729] text-lg mb-2">{item.title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section id="features" className="bg-slate-50 py-20 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <div className="section-label">Features</div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0F1729] mb-4">
            Everything you need to stay one step ahead
          </h2>
          <p className="text-slate-500 text-lg mb-12 max-w-xl mx-auto">
            Built specifically for Indian small businesses. Simple enough for anyone to use.
          </p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { icon: <TrendingUp size={20} />, bg: 'bg-blue-50 text-blue-600', title: 'Real competitor data', desc: 'Real ratings and reviews pulled directly from Google every week. Not guesses.' },
              { icon: <Zap size={20} />, bg: 'bg-purple-50 text-purple-600', title: 'AI-powered analysis', desc: 'Our AI reads hundreds of reviews and finds what matters for YOUR business.' },
              { icon: <Bell size={20} />, bg: 'bg-red-50 text-red-600', title: 'Threat alerts', desc: 'Know when a competitor is getting better before your customers notice.' },
              { icon: <Lightbulb size={20} />, bg: 'bg-amber-50 text-amber-600', title: 'Opportunity finder', desc: 'Discover what customers want that nobody near you is offering yet.' },
              { icon: <BarChart2 size={20} />, bg: 'bg-emerald-50 text-emerald-600', title: 'Detailed analytics', desc: 'Dig deeper into ratings, trends, and complaint patterns whenever you want.' },
              { icon: <Smartphone size={20} />, bg: 'bg-slate-100 text-slate-600', title: 'Works on any device', desc: 'Check your report on your phone, tablet, or computer. Always ready.' },
            ].map((f, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 text-left shadow-card hover:shadow-card-hover transition-shadow duration-200">
                <div className={`${f.bg} w-10 h-10 rounded-xl flex items-center justify-center mb-4`}>
                  {f.icon}
                </div>
                <h3 className="font-bold text-[#0F1729] mb-2">{f.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ── */}
      <section id="pricing" className="bg-white py-20 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="section-label">Pricing</div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0F1729] mb-4">Simple pricing. No surprises.</h2>
          <p className="text-slate-500 text-lg mb-12">Start free. Upgrade when you're ready.</p>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Free */}
            <div className="border-2 border-slate-200 rounded-2xl p-8 text-left">
              <div className="text-3xl font-bold text-[#0F1729] mb-1">Free</div>
              <div className="text-slate-500 mb-6">Perfect to get started</div>
              <ul className="space-y-3 mb-8">
                {['One competitor report', '3 competitors tracked', 'Basic insights', 'No credit card needed'].map((f, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-700">
                    <Check size={16} className="text-emerald-500 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => navigate('/start')}
                className="w-full border-2 border-[#0F1729] text-[#0F1729] font-semibold py-3 rounded-xl hover:bg-slate-50 transition-colors"
              >
                Start Free
              </button>
            </div>

            {/* Pro */}
            <div className="bg-[#0F1729] rounded-2xl p-8 text-left relative overflow-hidden">
              <div className="absolute top-4 right-4 bg-amber-400 text-[#0F1729] text-xs font-bold px-3 py-1 rounded-full">
                Most Popular
              </div>
              <div className="text-3xl font-bold text-white mb-1">₹499<span className="text-lg font-normal text-white/60">/month</span></div>
              <div className="text-white/60 mb-6">For serious business owners</div>
              <ul className="space-y-3 mb-8">
                {[
                  'Weekly automated reports',
                  'Up to 10 competitors tracked',
                  'Full AI analysis',
                  'Threat alerts',
                  'Opportunity finder',
                  'Email digest every Monday',
                ].map((f, i) => (
                  <li key={i} className="flex items-center gap-3 text-white/80">
                    <Check size={16} className="text-amber-400 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => navigate('/start')}
                className="w-full bg-amber-400 hover:bg-amber-500 text-[#0F1729] font-bold py-3 rounded-xl transition-colors"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="bg-[#0F1729] py-16 px-4 text-center">
        <div className="max-w-xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to outsmart your competition?</h2>
          <p className="text-white/60 mb-8">Join thousands of small business owners getting smarter every week.</p>
          <button
            onClick={() => navigate('/start')}
            className="bg-amber-400 hover:bg-amber-500 text-[#0F1729] font-bold px-10 py-4 rounded-xl text-lg transition-all duration-200 flex items-center gap-2 mx-auto active:scale-95"
          >
            Start For Free <ArrowRight size={20} />
          </button>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="bg-[#080e1a] py-8 px-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">🔍</span>
            <span className="text-white font-bold">Scout</span>
          </div>
          <div className="flex gap-6 text-white/40 text-sm">
            <a href="#" className="hover:text-white/70 transition-colors">Privacy</a>
            <a href="#" className="hover:text-white/70 transition-colors">Terms</a>
            <a href="#" className="hover:text-white/70 transition-colors">Contact</a>
          </div>
          <div className="text-white/40 text-sm">Made with ❤️ for Indian small businesses</div>
        </div>
      </footer>
    </div>
  )
}
