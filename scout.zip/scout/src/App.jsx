import React, { useState } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Landing from './pages/Landing.jsx'
import Onboarding from './pages/Onboarding.jsx'
import Discovery from './pages/Discovery.jsx'
import Dashboard from './pages/Dashboard.jsx'
import NotFound from './pages/NotFound.jsx'

export default function App() {
  const [businessInfo, setBusinessInfo] = useState(null)
  const [placeData, setPlaceData] = useState(null)
  const [competitors, setCompetitors] = useState([])
  const [analysis, setAnalysis] = useState(null)

  return (
    <Routes>
      <Route path="/" element={<Landing />} />

      <Route
        path="/start"
        element={
          <Onboarding
            setBusinessInfo={setBusinessInfo}
            setPlaceData={setPlaceData}
          />
        }
      />

      <Route
        path="/discovery"
        element={
          businessInfo ? (
            <Discovery
              businessInfo={businessInfo}
              placeData={placeData}
              setCompetitors={setCompetitors}
              setAnalysis={setAnalysis}
            />
          ) : (
            <Navigate to="/start" replace />
          )
        }
      />

      <Route
        path="/dashboard"
        element={
          analysis ? (
            <Dashboard
              businessInfo={businessInfo}
              competitors={competitors}
              analysis={analysis}
            />
          ) : (
            <Navigate to="/start" replace />
          )
        }
      />

      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
