# 🔍 Scout — AI Competitive Intelligence for Small Businesses

> Know exactly what your competitors are doing — every week.

Scout monitors your competitors on Google and delivers one clear weekly action
telling any small business owner exactly what to do to stay ahead.

---

## 🚀 Setup in 5 Minutes

### Step 1 — Install dependencies
```bash
npm install
```

### Step 2 — Add your API keys
```bash
cp .env.example .env
```
Open `.env` and fill in:
```
GOOGLE_PLACES_API_KEY=your_key_here
CLAUDE_API_KEY=your_key_here
```

**Get Google Places API key:**
1. Go to https://console.cloud.google.com
2. Create a new project named "scout"
3. Go to APIs & Services → Library
4. Search "Places API" → Enable it
5. Go to APIs & Services → Credentials
6. Click "+ Create Credentials" → API Key
7. Copy the key into .env

**Get Claude API key:**
1. Go to https://console.anthropic.com
2. Sign up / log in
3. Go to API Keys → Create new key
4. Copy the key into .env

### Step 3 — Start the app
```bash
npm start
```

This runs both the backend server (port 3001) and frontend (port 5173).

Open http://localhost:5173 in your browser. 🎉

---

## 🏗️ Project Structure

```
scout/
├── server.js          # Express backend — proxies Google Places + Claude API
├── src/
│   ├── App.jsx        # Router + global state
│   ├── index.css      # Tailwind + custom styles
│   ├── pages/
│   │   ├── Landing.jsx     # Marketing homepage
│   │   ├── Onboarding.jsx  # 3-step business registration form
│   │   ├── Discovery.jsx   # Loading screen + competitor results
│   │   ├── Dashboard.jsx   # Intelligence report + analytics
│   │   └── NotFound.jsx    # 404 page
│   └── services/
│       └── api.js          # API helper functions
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React + Vite + Tailwind CSS |
| Backend | Express.js |
| Data | Google Places API |
| Intelligence | Claude API (claude-sonnet-4-20250514) |
| Charts | Recharts |
| Animations | Framer Motion |
| Icons | Lucide React |
| Deployment | Vercel / Replit |

---

## 📱 Screens

1. **Landing page** — Hero, how it works, features, pricing
2. **Onboarding** — 3-step form (name → category → location)
3. **Competitor Discovery** — Live loading + animated competitor cards
4. **Intelligence Dashboard** — Weekly action + full analytics
   - Simple view (for non-technical users)
   - Detailed analytics (expandable for power users)

---

## 🎯 Demo Script (Hackathon)

1. Open Scout on screen
2. Say: *"A Starbucks manager gets weekly competitor intelligence. A local café owner gets nothing. We built Scout to fix that."*
3. Click "Start Free"
4. Enter a real restaurant near the hackathon venue
5. Show competitors loading live — real business names, real ratings
6. Show the AI-generated weekly action card
7. Say: *"This business owner just got intelligence that big chains pay lakhs for. It took Scout 20 seconds."*

---

## 💰 Business Model

- **Free tier:** One competitor report, 3 competitors
- **Pro:** ₹499/month — weekly automated reports, 10 competitors, email digest
- **API costs:** ~₹50/business/month → strong margins from day one

---

## ❓ Judge Questions — Quick Answers

**"Can't they just Google it themselves?"**
→ Takes 4+ hours per week. Scout does it in 20 seconds, automatically, every week.

**"Isn't scraping against ToS?"**
→ We use official Google Places API — paid, legal, legitimate.

**"What about SEMrush/Crayon?"**
→ They track digital/SaaS companies. We're built for physical Indian SMBs. Completely different market.

**"What's your moat?"**
→ India-specific SMB focus, proprietary dataset of local business patterns, distribution via WhatsApp.

---

Built with ❤️ for Indian small businesses.
